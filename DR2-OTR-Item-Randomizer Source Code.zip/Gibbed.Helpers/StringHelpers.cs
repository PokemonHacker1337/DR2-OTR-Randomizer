namespace Gibbed.Helpers
{
	public static class StringHelpers
	{
	}
}
