using Gibbed.DeadRising2.FileFormats;

namespace Gibbed.DeadRising2.Unpack
{
	internal class MyEntry : BigFile.Entry
	{
		public string Path;
	}
}
