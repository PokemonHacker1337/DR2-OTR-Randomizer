namespace ICSharpCode.SharpZipLib.Tar
{
	public delegate void ProgressMessageHandler(TarArchive archive, TarEntry entry, string message);
}
