using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Security;
using System.Security.Permissions;

[assembly: AssemblyCopyright("Copyright © Gibbed 2010")]
[assembly: AssemblyTitle("Item Randomizer")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("Randomizer")]
[assembly: Guid("b4704a34-15bf-43ea-8a7e-05ad5724b8d8")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: ComVisible(false)]
[assembly: AssemblyVersion("1.0.0.0")]
