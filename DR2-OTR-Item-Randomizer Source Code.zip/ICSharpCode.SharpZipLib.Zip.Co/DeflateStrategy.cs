namespace ICSharpCode.SharpZipLib.Zip.Compression
{
	public enum DeflateStrategy
	{
		Default,
		Filtered,
		HuffmanOnly
	}
}
