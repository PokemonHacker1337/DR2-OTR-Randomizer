Made using Gibbed's Datafile unpacker as a base to credits to him and his program.

Also credits to PKHacker1337 for making the original DR2 randomizer.

Known issues:

DR2:
Serving Tray missing prop item in the item list causing a crash when picked up.

OTR:
Entering Stacy's fight causes a crash due to an unknown necessary item being replaced.
