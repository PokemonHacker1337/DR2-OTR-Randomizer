namespace NDesk.Options
{
	public enum OptionValueType
	{
		None,
		Optional,
		Required
	}
}
