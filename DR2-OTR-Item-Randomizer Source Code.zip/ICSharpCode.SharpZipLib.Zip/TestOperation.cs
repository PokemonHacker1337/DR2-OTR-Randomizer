namespace ICSharpCode.SharpZipLib.Zip
{
	public enum TestOperation
	{
		Initialising,
		EntryHeader,
		EntryData,
		EntryComplete,
		MiscellaneousTests,
		Complete
	}
}
