namespace ICSharpCode.SharpZipLib.Zip
{
	public enum UseZip64
	{
		Off,
		On,
		Dynamic
	}
}
