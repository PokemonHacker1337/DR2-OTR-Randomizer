namespace ICSharpCode.SharpZipLib.Zip
{
	public delegate void ZipTestResultHandler(TestStatus status, string message);
}
