namespace ICSharpCode.SharpZipLib.Zip
{
	public enum FileUpdateMode
	{
		Safe,
		Direct
	}
}
