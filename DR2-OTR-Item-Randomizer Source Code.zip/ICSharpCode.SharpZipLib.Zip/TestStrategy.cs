namespace ICSharpCode.SharpZipLib.Zip
{
	public enum TestStrategy
	{
		FindFirstError,
		FindAllErrors
	}
}
