namespace ICSharpCode.SharpZipLib.Core
{
	public delegate void FileFailureHandler(object sender, ScanFailureEventArgs e);
}
