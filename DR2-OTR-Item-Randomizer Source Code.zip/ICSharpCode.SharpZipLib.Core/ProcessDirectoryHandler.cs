namespace ICSharpCode.SharpZipLib.Core
{
	public delegate void ProcessDirectoryHandler(object sender, DirectoryEventArgs e);
}
