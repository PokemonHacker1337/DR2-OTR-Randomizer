namespace ICSharpCode.SharpZipLib.Core
{
	public delegate void ProgressHandler(object sender, ProgressEventArgs e);
}
