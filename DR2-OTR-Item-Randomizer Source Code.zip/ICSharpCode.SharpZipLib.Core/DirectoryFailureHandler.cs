namespace ICSharpCode.SharpZipLib.Core
{
	public delegate void DirectoryFailureHandler(object sender, ScanFailureEventArgs e);
}
