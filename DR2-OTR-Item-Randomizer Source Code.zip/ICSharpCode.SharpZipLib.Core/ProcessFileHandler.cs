namespace ICSharpCode.SharpZipLib.Core
{
	public delegate void ProcessFileHandler(object sender, ScanEventArgs e);
}
