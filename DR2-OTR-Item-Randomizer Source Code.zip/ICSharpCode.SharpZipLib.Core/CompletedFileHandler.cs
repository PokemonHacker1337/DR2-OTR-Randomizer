namespace ICSharpCode.SharpZipLib.Core
{
	public delegate void CompletedFileHandler(object sender, ScanEventArgs e);
}
